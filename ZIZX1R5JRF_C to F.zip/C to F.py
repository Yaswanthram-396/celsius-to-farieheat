a=input()
a=float(a)
print(a*(9/5) + 32)